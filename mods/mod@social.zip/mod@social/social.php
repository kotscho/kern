<?php
print 'what\'s this about anyway?';
exit();

?>